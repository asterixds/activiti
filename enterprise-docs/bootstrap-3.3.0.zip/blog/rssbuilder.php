<?php
/**
 * RSS feeds builder for AsciiDoc-Bootstrap backend v3
 *
 * @author Laurent Laville
 * @license BSD-3-clause
 * @link https://github.com/llaville/asciidoc-bootstrap-backend
 */

/*
    <link rel="alternate" type="application/rss+xml" href="http://www.laurent-laville.org/asciidoc/bootstrap/blog/rss.xml" />
 */

require_once 'Symfony/Component/ClassLoader/UniversalClassLoader.php';

use Symfony\Component\ClassLoader\UniversalClassLoader;
use Symfony\Component\Finder\Finder;

$loader = new UniversalClassLoader();
$loader->registerNamespaces(array(
    'Symfony'  => __DIR__ . DIRECTORY_SEPARATOR . 'vendor',
));
$loader->register();

$source1 = dirname(__FILE__);

$finder = new Finder();
$finder->files()
    ->name('201*-*.asciidoc')
    ->in($source1);

$channel_link = 'http://www.laurent-laville.org/asciidoc/bootstrap';

$xml  = '<?xml version="1.0" encoding="iso-8859-1"?>' . "\n";
$xml .= '<rss version="2.0">' . "\n";
$xml .= '<channel>' . "\n";
$xml .= '<title>Official Blog of AsciiDoc Bootstrap backend</title>' . "\n";
$xml .= '<link>' . $channel_link . '</link>' . "\n";
$xml .= '<description>Official Blog of AsciiDoc Bootstrap backend</description>' . "\n";

foreach ($finder as $file) {
    $lines = file( $file->getRealpath() );
    #print_r ( $lines ); die;

    foreach ($lines as $line) {
        if (substr($line, 0, 2) == '==') {
            $title = trim(substr($line, 2));
        }
        elseif (substr($line, 0, 9) == ':pubdate:') {
            $pubdate = trim(substr($line, 9));
        }
        elseif (substr($line, 0, 9) == ':summary:') {
            $description = trim(substr($line, 9));
        }
    }
    $link = $channel_link . str_replace(dirname(__DIR__), '', $file->getRealpath());
    $link = str_replace(array('\\', '.asciidoc'), array('/', '.html'), $link);

    $xml .= '<item>' . "\n";
    $xml .= '<title>' . $title . '</title>' . "\n";
    $xml .= '<link>' . $link . '</link>' . "\n";
    $xml .= '<pubDate>' . $pubdate . '</pubDate>' . "\n";
    $xml .= '<description>' . $description . '</description>' . "\n";
    $xml .= '<guid>' . $link . '</guid>' . "\n";
    $xml .= '</item>' . "\n";
}
#echo $xml; die;

$xml .= '</channel>' . "\n";
$xml .= '</rss>';

$fp = fopen(__DIR__ . DIRECTORY_SEPARATOR . 'rss.xml', 'w+');
$bytes = fwrite($fp, $xml);
fclose($fp);
if ($bytes === false) {
    echo 'RSS feed was not generated'; 
} else {
    echo 'RSS feed is available'; 
}
